<template>
  <div class="home">
    <h1>Bienvenido al Sistema de Contactos</h1>
    <p>Seleccione una opción del menú superior</p>
  </div>
</template>

<style scoped>
.home {
  text-align: center;
  padding: 2rem;
}
</style>