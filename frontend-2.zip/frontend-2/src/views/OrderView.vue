<template>
  <section class="p-6 max-w-7xl mx-auto">
    <h1 class="text-2xl font-bold mb-6 text-gray-900">Órdenes</h1>

    <div class="max-w-md mb-8">
      <input
        id="search-input"
        v-model="busqueda"
        @input="buscarProductos"
        placeholder="Buscar productos..."
        class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        type="text"
      />
      <p v-if="loading" class="mt-2 text-gray-500">Buscando...</p>
      <ul
        v-if="!loading && productos.length"
        class="mt-2 border border-gray-300 rounded-md bg-white shadow-sm divide-y divide-gray-200"
      >
        <li
          v-for="producto in productos"
          :key="producto.id_item"
          class="px-4 py-2 hover:bg-gray-100 cursor-pointer"
          @click="agregarProducto(producto)"
        >
          {{ producto.cod_item }} - {{ producto.descripcion_item }} (Gs {{ producto.precio_unitario.toLocaleString('es-PY') }})
          [Stock: {{ producto.cantidad_inicial }}, IVA: {{ producto.porcentaje_iva }}%]
        </li>
      </ul>
      <p v-else-if="!loading && busqueda.trim().length >= 2" class="mt-2 text-gray-500">No se encontraron productos.</p>
    </div>

    <div class="mt-6">
      <h2 class="text-xl font-semibold mb-4 text-gray-900">Productos Seleccionados</h2>
      <div class="overflow-x-auto">
        <table class="w-full border-collapse bg-white shadow-sm rounded-md">
          <thead>
            <tr class="bg-gray-50">
              <th class="px-4 py-2 text-left text-sm">Cod</th>
              <th class="px-4 py-2 text-left text-sm">Cantidad</th>
              <th class="px-4 py-2 text-left text-sm">Descripción</th>
              <th class="px-4 py-2 text-left text-sm">Iva</th>
              <th class="px-4 py-2 text-left text-sm">Total</th>
              <th class="px-4 py-2 text-left text-sm">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="!itemsSeleccionados.length">
              <td colspan="6" class="px-4 py-4 text-center text-gray-500">No hay productos seleccionados.</td>
            </tr>
            <tr v-for="(item, index) in itemsSeleccionados" :key="item.id_item">
              <td class="px-4 py-2">{{ item.cod_item }}</td>
              <td class="px-4 py-2">
                <input
                  type="number"
                  v-model.number="item.cantidad"
                  :max="item.cantidad_inicial"
                  min="1"
                  class="w-20 px-2 py-1 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  @input="actualizarTotal(index)"
                />
              </td>
              <td class="px-4 py-2">{{ item.descripcion_item }}</td>
              <td class="px-4 py-2">{{ item.porcentaje_iva }}%</td>
              <td class="px-4 py-2">Gs {{ item.total.toLocaleString('es-PY') }}</td>
              <td class="px-4 py-2">
                <button @click="eliminarProducto(index)" class="text-red-600 hover:text-red-800">Eliminar</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="mt-4 text-right">
        <p class="text-lg font-semibold text-gray-900">Total General: Gs {{ totalGeneral.toLocaleString('es-PY') }}</p>
        <button
          @click="abrirModalProcesar"
          class="mt-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded"
        >
          Confirmar Orden
        </button>
      </div>
    </div>

    <ModelProcesarOrden
      v-if="showModal"
      :items="itemsSeleccionados"
      :total="totalGeneral"
      :numeroOrden="numeroOrden"
      @close="cerrarModalProcesar"
      @ordenProcesada="limpiarTodo"
    />
  </section>
</template>
<script setup>
import { ref, computed, watch, onMounted } from 'vue';
import api from '@/api/productos';
import ModelProcesarOrden from '@/components/ModelProcesarOrden.vue';

// Estados reactivos
const busqueda = ref('');
const productos = ref([]);
const loading = ref(false);
const itemsSeleccionados = ref([]);
const showModal = ref(false);
const numeroOrden = ref(Math.floor(Math.random() * 10000));

// Persistencia en sessionStorage
const cargarDesdeSessionStorage = () => {
  const itemsGuardados = sessionStorage.getItem('ordenItems');
  const numeroGuardado = sessionStorage.getItem('ordenNumero');
  
  if (itemsGuardados) {
    try {
      itemsSeleccionados.value = JSON.parse(itemsGuardados);
    } catch (e) {
      sessionStorage.removeItem('ordenItems');
    }
  }
  
  if (numeroGuardado) {
    numeroOrden.value = Number(numeroGuardado);
  }
};

const guardarEnSessionStorage = () => {
  sessionStorage.setItem('ordenItems', JSON.stringify(itemsSeleccionados.value));
  sessionStorage.setItem('ordenNumero', numeroOrden.value.toString());
};

// Watchers para persistencia automática
watch(itemsSeleccionados, guardarEnSessionStorage, { deep: true });
watch(numeroOrden, guardarEnSessionStorage);

// Cargar datos al montar el componente
onMounted(cargarDesdeSessionStorage);

// Métodos
const abrirModalProcesar = () => showModal.value = true;
const cerrarModalProcesar = () => showModal.value = false;

const limpiarTodo = () => {
  sessionStorage.removeItem('ordenItems');
  sessionStorage.removeItem('ordenNumero');
  itemsSeleccionados.value = [];
  productos.value = [];
  busqueda.value = '';
  numeroOrden.value = Math.floor(Math.random() * 10000);
  cerrarModalProcesar();
};

const buscarProductos = async () => {
  const termino = busqueda.value.trim();
  if (termino.length < 2) {
    productos.value = [];
    loading.value = false;
    return;
  }
  loading.value = true;
  try {
    const res = await api.buscarProductos(termino);
    productos.value = res.success ? res.data : [];
  } catch (err) {
    productos.value = [];
  } finally {
    loading.value = false;
  }
};

const agregarProducto = (producto) => {
  itemsSeleccionados.value.push({
    id_item: producto.id_item,
    cod_item: producto.cod_item,
    descripcion_item: producto.descripcion_item,
    precio_unitario: producto.precio_unitario,
    cantidad: 1,
    cantidad_inicial: producto.cantidad_inicial,
    porcentaje_iva: producto.porcentaje_iva,
    total: producto.precio_unitario * 1,
  });
  busqueda.value = '';
  productos.value = [];
};

const actualizarTotal = (index) => {
  const item = itemsSeleccionados.value[index];
  if (item.cantidad > item.cantidad_inicial) {
    item.cantidad = item.cantidad_inicial;
  }
  item.total = item.precio_unitario * item.cantidad;
};

const eliminarProducto = (index) => {
  itemsSeleccionados.value.splice(index, 1);
};

// Computed
const totalGeneral = computed(() => 
  itemsSeleccionados.value.reduce((sum, item) => sum + item.total, 0)
);
</script>

<!-- <script setup>
import { ref, computed } from 'vue';
import api from '@/api/productos';
import ModelProcesarOrden from '@/components/ModelProcesarOrden.vue'

const busqueda = ref('');
const productos = ref([]);
const loading = ref(false);
const itemsSeleccionados = ref([]);
const showModal = ref(false);
const numeroOrden = ref(Math.floor(Math.random() * 10000))

const abrirModalProcesar = () => showModal.value = true
const cerrarModalProcesar = () => showModal.value = false

const limpiarTodo = () => {
  itemsSeleccionados.value = []
  productos.value = []
  busqueda.value = ''
  numeroOrden.value = Math.floor(Math.random() * 10000)
  cerrarModalProcesar()
}

const buscarProductos = async () => {
  const termino = busqueda.value.trim();
  if (termino.length < 2) {
    productos.value = [];
    loading.value = false;
    return;
  }
  loading.value = true;
  try {
    const res = await api.buscarProductos(termino);
    if (res.success) productos.value = res.data;
    else productos.value = [];
  } catch (err) {
    productos.value = [];
  } finally {
    loading.value = false;
  }
};

const agregarProducto = (producto) => {
  const total = producto.precio_unitario * 1;
  itemsSeleccionados.value.push({
    id_item: producto.id_item,
    cod_item: producto.cod_item,
    descripcion_item: producto.descripcion_item,
    precio_unitario: producto.precio_unitario,
    cantidad: 1,
    cantidad_inicial: producto.cantidad_inicial,
    porcentaje_iva: producto.porcentaje_iva,
    total: total,
  });
  busqueda.value = '';
  productos.value = [];
};

const actualizarTotal = (index) => {
  const item = itemsSeleccionados.value[index];
  if (item.cantidad > item.cantidad_inicial) item.cantidad = item.cantidad_inicial;
  item.total = item.precio_unitario * item.cantidad;
};

const eliminarProducto = (index) => {
  itemsSeleccionados.value.splice(index, 1);
};

const totalGeneral = computed(() => {
  return itemsSeleccionados.value.reduce((sum, item) => sum + item.total, 0);
});
</script> -->
