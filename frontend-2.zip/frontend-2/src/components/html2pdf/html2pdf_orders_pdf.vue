<template>
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div v-if="cargando" class="bg-white p-6 rounded-lg shadow-lg text-center">
      <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
      <p class="text-lg font-medium">Generando PDF...</p>
    </div>
    <div v-if="error" class="bg-white p-6 rounded-lg shadow-lg max-w-md">
      <h3 class="text-lg font-bold text-red-600 mb-2">Error al generar PDF</h3>
      <p class="mb-4">{{ error }}</p>
      <button 
        @click="emit('cerrar')" 
        class="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
      >
        Cerrar
      </button>
    </div>
    
    <!-- Contenido HTML para convertir a PDF (oculto) -->
    <div v-if="orderData" id="pdf-content" class="hidden">
      <!-- Removed all Tailwind classes that might cause color parsing issues -->
      <div style="background-color: white; padding: 32px; max-width: 768px; margin: 0 auto;">
        <h1 style="font-size: 24px; font-weight: bold; text-align: center; margin-bottom: 24px;">ORDEN DE VENTA</h1>
        
        <div style="margin-bottom: 24px;">
          <p style="font-size: 18px;"><strong>Número:</strong> {{ orderData.numero_order }}</p>
          <p style="font-size: 18px;"><strong>Fecha:</strong> {{ formatDate(orderData.fecha_expedicion) }}</p>
          <p style="font-size: 18px;"><strong>Condición de Pago:</strong> {{ orderData.describe_condicion }}</p>
        </div>
        
        <!-- Añadimos la información del cliente -->
        <div style="margin-bottom: 24px; padding: 12px; border: 1px solid #ccc; background-color: #f9f9f9;">
          <h3 style="font-size: 18px; font-weight: bold; margin-bottom: 8px;">Datos del Cliente</h3>
          <p style="margin-bottom: 4px;"><strong>Razón Social:</strong> {{ orderData.razon_social }}</p>
          <p><strong>RUC/CI:</strong> {{ orderData.ruc_ci || 'N/A' }}</p>
        </div>
        
        <h2 style="font-size: 20px; font-weight: bold; margin-bottom: 12px;">DETALLE DE ITEMS</h2>
        <table style="width: 100%; border-collapse: collapse; border: 1px solid #ccc; margin-bottom: 24px;">
          <thead style="background-color: #eee;">
            <tr>
              <th style="border: 1px solid #ccc; padding: 8px; text-align: left;">Código</th>
              <th style="border: 1px solid #ccc; padding: 8px; text-align: left;">Descripción</th>
              <th style="border: 1px solid #ccc; padding: 8px; text-align: right;">Cantidad</th>
              <th style="border: 1px solid #ccc; padding: 8px; text-align: right;">Precio</th>
              <th style="border: 1px solid #ccc; padding: 8px; text-align: right;">Total</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in items" :key="index">
              <td style="border: 1px solid #ccc; padding: 8px;">{{ item.cod_item }}</td>
              <td style="border: 1px solid #ccc; padding: 8px;">{{ item.descripcion_item }}</td>
              <td style="border: 1px solid #ccc; padding: 8px; text-align: right;">{{ item.cantidad }}</td>
              <td style="border: 1px solid #ccc; padding: 8px; text-align: right;">{{ formatNumber(item.precio_unitario) }}</td>
              <td style="border: 1px solid #ccc; padding: 8px; text-align: right;">{{ formatNumber(item.total_item) }}</td>
            </tr>
          </tbody>
        </table>
        
        <div style="display: flex; justify-content: flex-end;">
          <table style="width: auto;">
            <tbody>
              <tr>
                <td style="text-align: right; padding: 4px;">Gravado 10%:</td>
                <td style="text-align: right; padding: 4px;">{{ formatNumber(totales.totalGravado10) }}</td>
              </tr>
              <tr>
                <td style="text-align: right; padding: 4px;">Gravado 5%:</td>
                <td style="text-align: right; padding: 4px;">{{ formatNumber(totales.totalGravado5) }}</td>
              </tr>
              <tr>
                <td style="text-align: right; padding: 4px;">Exenta:</td>
                <td style="text-align: right; padding: 4px;">{{ formatNumber(totales.totalExenta) }}</td>
              </tr>
              <tr>
                <td style="text-align: right; padding: 4px;">IVA:</td>
                <td style="text-align: right; padding: 4px;">{{ formatNumber(totales.totalIVA) }}</td>
              </tr>
              <tr style="font-weight: bold;">
                <td style="text-align: right; padding: 4px; border-top: 1px solid #ccc;">TOTAL:</td>
                <td style="text-align: right; padding: 4px; border-top: 1px solid #ccc;">{{ formatNumber(totales.totalGeneral) }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref, computed } from 'vue'
import html2pdf from 'html2pdf.js'
import ordersApi from '@/api/orders'

const props = defineProps({
  orderId: {
    type: Number,
    required: true
  }
})

const emit = defineEmits(['cerrar'])
const cargando = ref(true)
const error = ref(null)
const items = ref([])
const orderData = ref(null)

const totales = computed(() => {
  let totalGravado10 = 0
  let totalGravado5 = 0
  let totalExenta = 0
  let totalIVA = 0
  let totalGeneral = 0
  
  items.value.forEach(item => {
    totalGravado10 += item.gravado_10 || 0
    totalGravado5 += item.gravado_5 || 0
    totalExenta += item.exenta || 0
    totalIVA += item.iva_calculado || 0
    totalGeneral += item.total_a_pagar || 0
  })
  
  return {
    totalGravado10,
    totalGravado5,
    totalExenta,
    totalIVA,
    totalGeneral
  }
})

const generarPDF = async () => {
  console.log('Generando PDF para la orden ID:', props.orderId)
  
  try {
    if (!props.orderId) {
      throw new Error('No se proporcionó un ID de orden válido')
    }

    const res = await ordersApi.getOrderForPrint(props.orderId)
    console.log('Respuesta de getOrderForPrint:', res)
    
    if (!res.success) {
      throw new Error(res.error || 'Error al obtener datos de la orden')
    }

    const data = res.data
    if (!data || data.length === 0) {
      throw new Error('No hay datos para generar el PDF')
    }

    console.log('Datos de la orden obtenidos correctamente:', data)
    
    items.value = data
    orderData.value = data[0]
    
    // Esperar a que el DOM se actualice
    await new Promise(resolve => setTimeout(resolve, 100))
    
    // Create a simple HTML string instead of using DOM elements
    const htmlContent = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ccc; padding: 8px; }
            th { background-color: #eee; text-align: left; }
            .text-right { text-align: right; }
            .total-row { font-weight: bold; border-top: 1px solid #000; }
            .client-info { margin-bottom: 20px; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; }
          </style>
        </head>
        <body>
          <h1 style="text-align: center; font-size: 24px;">ORDEN DE COMPRA</h1>
          
          <div style="display: flex; justify-content: space-between;">
            <div>
              <p><strong>Número:</strong> ${orderData.value.numero_order}</p>
              <p><strong>Fecha:</strong> ${formatDate(orderData.value.fecha_expedicion)}</p>
              <p><strong>Condición de Pago:</strong> ${orderData.value.describe_condicion}</p>
            </div>
          </div>
          
          <div class="client-info">
            <h3 style="margin-top: 0; margin-bottom: 10px;">Datos del Cliente</h3>
            <p><strong>Razón Social:</strong> ${orderData.value.razon_social}</p>
            <p style="margin-bottom: 0;"><strong>RUC/CI:</strong> ${orderData.value.ruc_ci || 'N/A'}</p>
          </div>
          
          <h2>DETALLE DE ITEMS</h2>
          <table>
            <thead>
              <tr>
                <th>Código</th>
                <th>Descripción</th>
                <th class="text-right">Cantidad</th>
                <th class="text-right">Precio</th>
                <th class="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              ${items.value.map(item => `
                <tr>
                  <td>${item.cod_item}</td>
                  <td>${item.descripcion_item}</td>
                  <td class="text-right">${item.cantidad}</td>
                  <td class="text-right">${formatNumber(item.precio_unitario)}</td>
                  <td class="text-right">${formatNumber(item.total_item)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          
          <div style="margin-top: 20px; text-align: right;">
            <table style="width: auto; margin-left: auto;">
              <tr>
                <td class="text-right">Gravado 10%:</td>
                <td class="text-right">${formatNumber(totales.value.totalGravado10)}</td>
              </tr>
              <tr>
                <td class="text-right">Gravado 5%:</td>
                <td class="text-right">${formatNumber(totales.value.totalGravado5)}</td>
              </tr>
              <tr>
                <td class="text-right">Exenta:</td>
                <td class="text-right">${formatNumber(totales.value.totalExenta)}</td>
              </tr>
              <tr>
                <td class="text-right">IVA:</td>
                <td class="text-right">${formatNumber(totales.value.totalIVA)}</td>
              </tr>
              <tr class="total-row">
                <td class="text-right">TOTAL:</td>
                <td class="text-right">${formatNumber(totales.value.totalGeneral)}</td>
              </tr>
            </table>
          </div>
          
          <div style="margin-top: 60px; display: flex; justify-content: space-between;">
            <div style="width: 40%; text-align: center;">
              <div style="border-top: 1px solid #000; padding-top: 5px;">Firma Cliente</div>
            </div>
            <div style="width: 40%; text-align: center;">
              <div style="border-top: 1px solid #000; padding-top: 5px;">Firma Autorizada</div>
            </div>
          </div>
        </body>
      </html>
    `;
    
    // Use jsPDF directly
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF();
    
    // Use html2canvas to render the HTML string
    const { default: html2canvas } = await import('html2canvas');
    
    // Create a temporary div to hold our HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = htmlContent;
    document.body.appendChild(tempDiv);
    
    try {
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        logging: true,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = canvas.height * imgWidth / canvas.width;
      
      doc.addImage(imgData, 'JPEG', 0, 0, imgWidth, imgHeight);
      
      // Open PDF in new window
      const pdfOutput = doc.output('datauristring');
      const newWindow = window.open();
      if (!newWindow) {
        throw new Error('El navegador bloqueó la apertura de la ventana. Por favor, permita ventanas emergentes.');
      }
      
      newWindow.document.write(`
        <iframe width="100%" height="100%" src="${pdfOutput}"></iframe>
      `);
    } finally {
      document.body.removeChild(tempDiv);
    }
    
    console.log('PDF generado correctamente');
    cargando.value = false;
    setTimeout(() => {
      emit('cerrar');
    }, 2000);
  } catch (err) {
    console.error('Error al generar el PDF:', err);
    cargando.value = false;
    error.value = err.message || 'Error desconocido al generar el PDF';
  }
};

const formatNumber = (num) => {
  if (num === undefined || num === null) return '0'
  return num.toLocaleString('es-PY')
}

const formatDate = (dateString) => {
  if (!dateString) return ''
  return new Date(dateString).toLocaleDateString('es-PY')
}

onMounted(() => {
  console.log('Componente HTML2PDF OrdersPdf montado con orderId:', props.orderId)
  generarPDF()
})
</script>