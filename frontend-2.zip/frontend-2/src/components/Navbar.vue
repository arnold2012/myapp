<template>
  <nav class="navbar">
    <router-link 
      v-for="route in routes" 
      :key="route.path" 
      :to="route.path"
      class="nav-link"
      :class="{ 'active': $route.path === route.path }"
    >
      <span class="icon">{{ route.meta?.icon }}</span>
      {{ route.name }}
    </router-link>
  </nav>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const routes = computed(() => {
  return router.options.routes.filter(route => route.name) // Solo rutas con nombre
})
</script>

<style scoped>
.navbar {
  display: flex;
  background: #2c3e50;
  padding: 1rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.nav-link {
  color: white;
  text-decoration: none;
  padding: 0.5rem 1rem;
  margin: 0 0.5rem;
  border-radius: 4px;
  display: flex;
  align-items: center;
  transition: all 0.3s ease;
}

.nav-link:hover {
  background: #34495e;
}

.nav-link.active {
  background: #42b983;
  font-weight: bold;
}

.icon {
  margin-right: 8px;
  font-size: 1.1em;
}
</style>