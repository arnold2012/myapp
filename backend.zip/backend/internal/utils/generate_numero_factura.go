package utils

import (
	"database/sql"
	"fmt"
)

// GenerateNumeroFactura genera el número de factura completo en base a los IDs de establecimiento y punto de expedición
func GenerateNumeroFactura(db *sql.DB, idEstablecimiento, idPuntoExpedicion int64, secuencial int64) (string, error) {
	var numeroEstablecimiento, numeroPunto string

	// Obtener número de establecimiento
	err := db.QueryRow(`SELECT numero_estableciminto FROM establecimiento WHERE id_establecimiento = $1`, idEstablecimiento).Scan(&numeroEstablecimiento)
	if err != nil {
		return "", fmt.Errorf("error obteniendo número de establecimiento: %w", err)
	}

	// Obtener número de punto de expedición
	err = db.QueryRow(`SELECT numero_expedicion FROM punto_expedicion WHERE id_punto_expedicion = $1`, idPuntoExpedicion).Scan(&numeroPunto)
	if err != nil {
		return "", fmt.Errorf("error obteniendo número de punto de expedición: %w", err)
	}

	// Formatear el número de factura
	numeroFactura := fmt.Sprintf("%03s-%03s-%07d", numeroEstablecimiento, numeroPunto, secuencial)
	return numeroFactura, nil
}
