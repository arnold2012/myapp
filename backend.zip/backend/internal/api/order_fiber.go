package api

import (
    "backend/internal/db"
    "database/sql"
    "github.com/gofiber/fiber/v2"
    "context"
    "net/http"
)

func RegisterOrderRoutes(app *fiber.App, dbConn *sql.DB) {
    app.Post("/api/orders", func(c *fiber.Ctx) error {
        var params db.InsertOrderParams

        if err := c.BodyParser(&params); err != nil {
            return c.Status(http.StatusBadRequest).JSON(fiber.Map{
                "error": "JSON inválido",
            })
        }

        if len(params.Items) == 0 {
            return c.Status(http.StatusBadRequest).JSON(fiber.Map{
                "error": "Se requiere al menos un item",
            })
        }

        err := db.InsertSalesOrder(context.Background(), dbConn, params)
        if err != nil {
            return c.Status(http.StatusInternalServerError).JSON(fiber.Map{
                "error": err.Error(),
            })
        }

        return c.Status(http.StatusCreated).JSON(fiber.Map{
            "message": "Orden creada con éxito",
        })
    })
}
